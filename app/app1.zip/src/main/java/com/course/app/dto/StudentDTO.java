package com.course.app.dto;

import com.course.app.entity.Student;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentDTO {
    
    private Long id;
    private String nationalId;
    private String firstName;
    private String lastName;
    private String motherName;
    private String fatherName;
    private String address;
    private String phone;
    private LocalDate birthDate;
    private Integer totalScore;
    private String teacherComment;
    private Long userId;
    private String username;
    private LocalDate createdAt;
    private LocalDate updatedAt;
    private List<CourseLocationDTO> courseLocations;
    
    // Static method to convert entity to DTO
    public static StudentDTO fromEntity(Student student) {
        if (student == null) return null;
        
        StudentDTO dto = new StudentDTO();
        dto.setId(student.getId());
        dto.setNationalId(student.getNationalId());
        dto.setFirstName(student.getFirstName());
        dto.setLastName(student.getLastName());
        dto.setMotherName(student.getMotherName());
        dto.setFatherName(student.getFatherName());
        dto.setAddress(student.getAddress());
        dto.setPhone(student.getPhone());
        dto.setBirthDate(student.getBirthDate());
        dto.setTotalScore(student.getTotalScore());
        dto.setTeacherComment(student.getTeacherComment());
        
        if (student.getUser() != null) {
            dto.setUserId(student.getUser().getId());
            dto.setUsername(student.getUser().getUsername());
        }
        
        dto.setCreatedAt(student.getCreatedAt() != null ? student.getCreatedAt().toLocalDate() : null);
        dto.setUpdatedAt(student.getUpdatedAt() != null ? student.getUpdatedAt().toLocalDate() : null);
        
        return dto;
    }
    
    // Convert list of entities to list of DTOs
    public static List<StudentDTO> fromEntities(List<Student> students) {
        if (students == null) return new ArrayList<>();
        
        return students.stream()
                .map(StudentDTO::fromEntity)
                .collect(Collectors.toList());
    }
}
