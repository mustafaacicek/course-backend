package com.course.app.entity;

public enum Role {
    SUPERADMIN,
    ADMIN,
    STUDENT
}
